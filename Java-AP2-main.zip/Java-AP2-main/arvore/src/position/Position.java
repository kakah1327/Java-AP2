package position;

public interface Position<E> {
	// Retorna o elemento armazenado nesta posição.
	E element();
}
